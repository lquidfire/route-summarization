# CIDR Route Summarizaion

CIDR classes summarization using [Perl Net::CIDR::Lite](https://metacpan.org/dist/Net-CIDR-Lite/view/Lite.pm) inspired by [Random Thoughts](http://adrianpopagh.blogspot.com/2008/03/route-summarization-script.html)


## Project intergrations

Becase this uses STDIO, intergrating this Perl script into other workflows (i.e. BASH, TCL, etc) is minimal

* [Postallow](https://github.com/lquidfire/postallow)
